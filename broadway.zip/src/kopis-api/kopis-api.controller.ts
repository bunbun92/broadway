import { Controller, Get } from '@nestjs/common';
import { KopisApiService } from './kopis-api.service';

@Controller('kopis-api')
export class KopisApiController {
  constructor(private readonly kopisApiService: KopisApiService) {}

  @Get('/kopis')
  async kopisCreate() {
    const result =
      'https://www.kopis.or.kr/openApi/restful/pblprfr?service=8ac72359a2b74f5f883f610f5d8df103&stdate=20200601&eddate=20220930&cpage=1&rows=5&prfstate=02&signgucode=11&signgucodesub=1111';
    return await this.kopisApiService.kopisCreate();
  }
}
