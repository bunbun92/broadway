import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { KopisApi } from '../entities/kopisApi.entity';
import { Repository } from 'typeorm';

@Injectable()
export class KopisApiService {
  constructor(
    @InjectRepository(KopisApi) private kopisApiRepository: Repository<KopisApi>
  ) {}

  // async getApi(result){
  //     const newResult = new KopisApi();
  //     return await {"id": 1};
  // }

  async kopisCreate(): Promise<KopisApi> {
    return await this.kopisApiRepository.create({
      mt20id: 'djf2123',
    });
  }
}
